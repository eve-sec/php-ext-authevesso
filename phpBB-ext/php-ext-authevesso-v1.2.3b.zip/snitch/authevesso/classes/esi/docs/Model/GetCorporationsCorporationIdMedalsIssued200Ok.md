# GetCorporationsCorporationIdMedalsIssued200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**medal_id** | **int** | medal_id integer | 
**character_id** | **int** | ID of the character who was rewarded this medal | 
**reason** | **string** | reason string | 
**status** | **string** | status string | 
**issuer_id** | **int** | ID of the character who issued the medal | 
**issued_at** | [**\DateTime**](\DateTime.md) | issued_at string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


