# GetCharactersCharacterIdStatsIndustry

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hacking_successes** | **int** | hacking_successes integer | [optional] 
**jobs_cancelled** | **int** | jobs_cancelled integer | [optional] 
**jobs_completed_copy_blueprint** | **int** | jobs_completed_copy_blueprint integer | [optional] 
**jobs_completed_invention** | **int** | jobs_completed_invention integer | [optional] 
**jobs_completed_manufacture** | **int** | jobs_completed_manufacture integer | [optional] 
**jobs_completed_manufacture_asteroid** | **int** | jobs_completed_manufacture_asteroid integer | [optional] 
**jobs_completed_manufacture_asteroid_quantity** | **int** | jobs_completed_manufacture_asteroid_quantity integer | [optional] 
**jobs_completed_manufacture_charge** | **int** | jobs_completed_manufacture_charge integer | [optional] 
**jobs_completed_manufacture_charge_quantity** | **int** | jobs_completed_manufacture_charge_quantity integer | [optional] 
**jobs_completed_manufacture_commodity** | **int** | jobs_completed_manufacture_commodity integer | [optional] 
**jobs_completed_manufacture_commodity_quantity** | **int** | jobs_completed_manufacture_commodity_quantity integer | [optional] 
**jobs_completed_manufacture_deployable** | **int** | jobs_completed_manufacture_deployable integer | [optional] 
**jobs_completed_manufacture_deployable_quantity** | **int** | jobs_completed_manufacture_deployable_quantity integer | [optional] 
**jobs_completed_manufacture_drone** | **int** | jobs_completed_manufacture_drone integer | [optional] 
**jobs_completed_manufacture_drone_quantity** | **int** | jobs_completed_manufacture_drone_quantity integer | [optional] 
**jobs_completed_manufacture_implant** | **int** | jobs_completed_manufacture_implant integer | [optional] 
**jobs_completed_manufacture_implant_quantity** | **int** | jobs_completed_manufacture_implant_quantity integer | [optional] 
**jobs_completed_manufacture_module** | **int** | jobs_completed_manufacture_module integer | [optional] 
**jobs_completed_manufacture_module_quantity** | **int** | jobs_completed_manufacture_module_quantity integer | [optional] 
**jobs_completed_manufacture_other** | **int** | jobs_completed_manufacture_other integer | [optional] 
**jobs_completed_manufacture_other_quantity** | **int** | jobs_completed_manufacture_other_quantity integer | [optional] 
**jobs_completed_manufacture_ship** | **int** | jobs_completed_manufacture_ship integer | [optional] 
**jobs_completed_manufacture_ship_quantity** | **int** | jobs_completed_manufacture_ship_quantity integer | [optional] 
**jobs_completed_manufacture_structure** | **int** | jobs_completed_manufacture_structure integer | [optional] 
**jobs_completed_manufacture_structure_quantity** | **int** | jobs_completed_manufacture_structure_quantity integer | [optional] 
**jobs_completed_manufacture_subsystem** | **int** | jobs_completed_manufacture_subsystem integer | [optional] 
**jobs_completed_manufacture_subsystem_quantity** | **int** | jobs_completed_manufacture_subsystem_quantity integer | [optional] 
**jobs_completed_material_productivity** | **int** | jobs_completed_material_productivity integer | [optional] 
**jobs_completed_time_productivity** | **int** | jobs_completed_time_productivity integer | [optional] 
**jobs_started_copy_blueprint** | **int** | jobs_started_copy_blueprint integer | [optional] 
**jobs_started_invention** | **int** | jobs_started_invention integer | [optional] 
**jobs_started_manufacture** | **int** | jobs_started_manufacture integer | [optional] 
**jobs_started_material_productivity** | **int** | jobs_started_material_productivity integer | [optional] 
**jobs_started_time_productivity** | **int** | jobs_started_time_productivity integer | [optional] 
**reprocess_item** | **int** | reprocess_item integer | [optional] 
**reprocess_item_quantity** | **int** | reprocess_item_quantity integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


