# GetCorporationsCorporationIdMedals200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**medal_id** | **int** | medal_id integer | 
**title** | **string** | title string | 
**description** | **string** | description string | 
**creator_id** | **int** | ID of the character who created this medal | 
**created_at** | [**\DateTime**](\DateTime.md) | created_at string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


