# GetCharactersCharacterIdStatsPve

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dungeons_completed_agent** | **int** | dungeons_completed_agent integer | [optional] 
**dungeons_completed_distribution** | **int** | dungeons_completed_distribution integer | [optional] 
**missions_succeeded** | **int** | missions_succeeded integer | [optional] 
**missions_succeeded_epic_arc** | **int** | missions_succeeded_epic_arc integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


