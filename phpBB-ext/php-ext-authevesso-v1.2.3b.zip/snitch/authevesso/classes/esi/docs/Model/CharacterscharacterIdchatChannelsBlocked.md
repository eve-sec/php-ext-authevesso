# CharacterscharacterIdchatChannelsBlocked

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accessor_id** | **int** | ID of a blocked channel member | 
**accessor_type** | **string** | accessor_type string | 
**end_at** | [**\DateTime**](\DateTime.md) | Time at which this accessor will no longer be blocked | [optional] 
**reason** | **string** | Reason this accessor is blocked | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


