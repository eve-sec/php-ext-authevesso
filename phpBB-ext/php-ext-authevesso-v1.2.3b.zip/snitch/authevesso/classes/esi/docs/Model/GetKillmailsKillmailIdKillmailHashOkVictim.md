# GetKillmailsKillmailIdKillmailHashOkVictim

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alliance_id** | **int** | alliance_id integer | [optional] 
**character_id** | **int** | character_id integer | [optional] 
**corporation_id** | **int** | corporation_id integer | [optional] 
**damage_taken** | **int** | How much total damage was taken by the victim | 
**faction_id** | **int** | faction_id integer | [optional] 
**items** | [**\Swagger\Client\Model\GetKillmailsKillmailIdKillmailHashOkVictimItems1[]**](GetKillmailsKillmailIdKillmailHashOkVictimItems1.md) | items array | [optional] 
**position** | [**\Swagger\Client\Model\GetKillmailsKillmailIdKillmailHashOkVictimPosition**](GetKillmailsKillmailIdKillmailHashOkVictimPosition.md) |  | [optional] 
**ship_type_id** | **int** | The ship that the victim was piloting and was destroyed | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


