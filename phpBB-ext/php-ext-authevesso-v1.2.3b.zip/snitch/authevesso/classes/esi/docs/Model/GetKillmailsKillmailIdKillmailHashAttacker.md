# GetKillmailsKillmailIdKillmailHashAttacker

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**character_id** | **int** | character_id integer | [optional] 
**corporation_id** | **int** | corporation_id integer | [optional] 
**alliance_id** | **int** | alliance_id integer | [optional] 
**faction_id** | **int** | faction_id integer | [optional] 
**security_status** | **float** | Security status for the attacker | 
**final_blow** | **bool** | Was the attacker the one to achieve the final blow | 
**damage_done** | **int** | damage_done integer | 
**ship_type_id** | **int** | What ship was the attacker flying | [optional] 
**weapon_type_id** | **int** | What weapon was used by the attacker for the kill | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


