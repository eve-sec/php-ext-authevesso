# GetCharactersCharacterIdFittings200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fitting_id** | **int** | fitting_id integer | 
**name** | **string** | name string | 
**description** | **string** | description string | 
**ship_type_id** | **int** | ship_type_id integer | 
**items** | [**\Swagger\Client\Model\GetCharactersCharacterIdFittingsItem[]**](GetCharactersCharacterIdFittingsItem.md) | items array | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


