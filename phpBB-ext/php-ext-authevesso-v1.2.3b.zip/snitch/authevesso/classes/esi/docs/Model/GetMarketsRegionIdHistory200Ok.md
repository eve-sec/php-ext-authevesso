# GetMarketsRegionIdHistory200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | [**\DateTime**](Date.md) | The date of this historical statistic entry | 
**order_count** | **int** | Total number of orders happened that day | 
**volume** | **int** | Total | 
**highest** | **double** | highest number | 
**average** | **double** | average number | 
**lowest** | **double** | lowest number | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


