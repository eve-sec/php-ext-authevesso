# GetCharactersCharacterIdPlanetsPlanetIdOkPins

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contents** | [**\Swagger\Client\Model\GetCharactersCharacterIdPlanetsPlanetIdOkContents[]**](GetCharactersCharacterIdPlanetsPlanetIdOkContents.md) | contents array | [optional] 
**expiry_time** | [**\DateTime**](\DateTime.md) | expiry_time string | [optional] 
**extractor_details** | [**\Swagger\Client\Model\GetCharactersCharacterIdPlanetsPlanetIdOkExtractorDetails**](GetCharactersCharacterIdPlanetsPlanetIdOkExtractorDetails.md) |  | [optional] 
**factory_details** | [**\Swagger\Client\Model\GetCharactersCharacterIdPlanetsPlanetIdOkFactoryDetails**](GetCharactersCharacterIdPlanetsPlanetIdOkFactoryDetails.md) |  | [optional] 
**install_time** | [**\DateTime**](\DateTime.md) | install_time string | [optional] 
**last_cycle_start** | [**\DateTime**](\DateTime.md) | last_cycle_start string | [optional] 
**latitude** | **float** | latitude number | 
**longitude** | **float** | longitude number | 
**pin_id** | **int** | pin_id integer | 
**schematic_id** | **int** | schematic_id integer | [optional] 
**type_id** | **int** | type_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


