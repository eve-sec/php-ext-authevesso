# GetCharactersCharacterIdFwStatsVictoryPoints

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**yesterday** | **int** | Yesterday&#39;s victory points gained by the given character | 
**last_week** | **int** | Last week&#39;s victory points gained by the given character | 
**total** | **int** | Total victory points gained since the given character enlisted | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


