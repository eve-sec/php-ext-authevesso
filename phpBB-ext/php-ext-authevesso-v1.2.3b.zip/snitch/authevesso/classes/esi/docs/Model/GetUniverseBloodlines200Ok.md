# GetUniverseBloodlines200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bloodline_id** | **int** | bloodline_id integer | 
**name** | **string** | name string | 
**description** | **string** | description string | 
**race_id** | **int** | race_id integer | 
**ship_type_id** | **int** | ship_type_id integer | 
**corporation_id** | **int** | corporation_id integer | 
**perception** | **int** | perception integer | 
**willpower** | **int** | willpower integer | 
**charisma** | **int** | charisma integer | 
**memory** | **int** | memory integer | 
**intelligence** | **int** | intelligence integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


