# GetCorporationsCorporationIdShareholders200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**shareholder_id** | **int** | shareholder_id integer | 
**shareholder_type** | **string** | shareholder_type string | 
**share_count** | **int** | share_count integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


