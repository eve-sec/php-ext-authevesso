# GetCharactersCharacterIdFatigueOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**last_jump_date** | [**\DateTime**](\DateTime.md) | Character&#39;s last jump activation | [optional] 
**jump_fatigue_expire_date** | [**\DateTime**](\DateTime.md) | Character&#39;s jump fatigue expiry | [optional] 
**last_update_date** | [**\DateTime**](\DateTime.md) | Character&#39;s last jump update | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


