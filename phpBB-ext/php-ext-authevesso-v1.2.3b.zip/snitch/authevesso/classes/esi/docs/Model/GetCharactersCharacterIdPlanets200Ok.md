# GetCharactersCharacterIdPlanets200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**solar_system_id** | **int** | solar_system_id integer | 
**planet_id** | **int** | planet_id integer | 
**owner_id** | **int** | owner_id integer | 
**upgrade_level** | **int** | upgrade_level integer | 
**num_pins** | **int** | num_pins integer | 
**last_update** | [**\DateTime**](\DateTime.md) | last_update string | 
**planet_type** | **string** | planet_type string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


