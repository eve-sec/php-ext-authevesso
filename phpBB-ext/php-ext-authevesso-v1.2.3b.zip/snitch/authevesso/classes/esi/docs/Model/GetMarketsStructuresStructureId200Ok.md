# GetMarketsStructuresStructureId200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**order_id** | **int** | order_id integer | 
**type_id** | **int** | type_id integer | 
**location_id** | **int** | location_id integer | 
**volume_total** | **int** | volume_total integer | 
**volume_remain** | **int** | volume_remain integer | 
**min_volume** | **int** | min_volume integer | 
**price** | **double** | price number | 
**is_buy_order** | **bool** | is_buy_order boolean | 
**duration** | **int** | duration integer | 
**issued** | [**\DateTime**](\DateTime.md) | issued string | 
**range** | **string** | range string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


