# GetCharactersCharacterIdCalendarEventIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**event_id** | **int** | event_id integer | 
**owner_id** | **int** | owner_id integer | 
**owner_name** | **string** | owner_name string | 
**date** | [**\DateTime**](\DateTime.md) | date string | 
**title** | **string** | title string | 
**duration** | **int** | Length in minutes | 
**importance** | **int** | importance integer | 
**response** | **string** | response string | 
**text** | **string** | text string | 
**owner_type** | **string** | owner_type string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


