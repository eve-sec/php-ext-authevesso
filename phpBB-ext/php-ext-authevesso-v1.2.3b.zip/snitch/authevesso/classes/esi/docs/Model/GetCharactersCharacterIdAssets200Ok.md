# GetCharactersCharacterIdAssets200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type_id** | **int** | type_id integer | 
**quantity** | **int** | quantity integer | 
**location_id** | **int** | location_id integer | 
**location_type** | **string** | location_type string | 
**item_id** | **int** | item_id integer | 
**location_flag** | **string** | location_flag string | 
**is_singleton** | **bool** | is_singleton boolean | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


