# GetCorporationsCorporationIdDivisionsOkHangar

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**division** | **int** | division integer | [optional] 
**name** | **string** | name string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


