# GetFleetsFleetIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**motd** | **string** | Fleet MOTD in CCP flavoured HTML | 
**is_free_move** | **bool** | Is free-move enabled | 
**is_registered** | **bool** | Does the fleet have an active fleet advertisement | 
**is_voice_enabled** | **bool** | Is EVE Voice enabled | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


