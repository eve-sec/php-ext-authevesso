# GetCharactersCharacterIdSkillqueue200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**skill_id** | **int** | skill_id integer | 
**finish_date** | [**\DateTime**](\DateTime.md) | finish_date string | [optional] 
**start_date** | [**\DateTime**](\DateTime.md) | start_date string | [optional] 
**finished_level** | **int** | finished_level integer | 
**queue_position** | **int** | queue_position integer | 
**training_start_sp** | **int** | training_start_sp integer | [optional] 
**level_end_sp** | **int** | level_end_sp integer | [optional] 
**level_start_sp** | **int** | Amount of SP that was in the skill when it started training it&#39;s current level. Used to calculate % of current level complete. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


