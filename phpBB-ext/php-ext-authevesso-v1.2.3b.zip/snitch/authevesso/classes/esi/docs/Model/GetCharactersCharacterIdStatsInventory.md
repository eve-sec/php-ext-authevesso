# GetCharactersCharacterIdStatsInventory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**abandon_loot_quantity** | **int** | abandon_loot_quantity integer | [optional] 
**trash_item_quantity** | **int** | trash_item_quantity integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


