# GetFwLeaderboardsCorporationsOkVictoryPointsYesterday

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **int** | Amount of victory points | [optional] 
**corporation_id** | **int** | corporation_id integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


