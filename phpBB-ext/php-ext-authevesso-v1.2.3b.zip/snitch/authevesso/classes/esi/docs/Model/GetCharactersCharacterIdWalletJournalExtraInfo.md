# GetCharactersCharacterIdWalletJournalExtraInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location_id** | **int** | location_id integer | [optional] 
**transaction_id** | **int** | transaction_id integer | [optional] 
**npc_name** | **string** | npc_name string | [optional] 
**npc_id** | **int** | npc_id integer | [optional] 
**destroyed_ship_type_id** | **int** | destroyed_ship_type_id integer | [optional] 
**character_id** | **int** | character_id integer | [optional] 
**corporation_id** | **int** | corporation_id integer | [optional] 
**alliance_id** | **int** | alliance_id integer | [optional] 
**job_id** | **int** | job_id integer | [optional] 
**contract_id** | **int** | contract_id integer | [optional] 
**system_id** | **int** | system_id integer | [optional] 
**planet_id** | **int** | planet_id integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


