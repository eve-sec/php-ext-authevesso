# GetCorporationsCorporationIdRolesHistory200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**character_id** | **int** | The character whose roles are changed | 
**changed_at** | [**\DateTime**](\DateTime.md) | changed_at string | 
**issuer_id** | **int** | ID of the character who issued this change | 
**role_type** | **string** | role_type string | 
**old_roles** | **string[]** | old_roles array | 
**new_roles** | **string[]** | new_roles array | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


