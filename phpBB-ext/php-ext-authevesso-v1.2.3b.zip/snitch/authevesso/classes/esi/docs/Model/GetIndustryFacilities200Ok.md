# GetIndustryFacilities200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**facility_id** | **int** | ID of the facility | 
**tax** | **float** | Tax imposed by the facility | [optional] 
**owner_id** | **int** | Owner of the facility | 
**type_id** | **int** | Type ID of the facility | 
**solar_system_id** | **int** | Solar system ID where the facility is | 
**region_id** | **int** | Region ID where the facility is | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


