# GetAlliancesAllianceIdContacts200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**standing** | **float** | Standing of the contact | 
**contact_type** | **string** | contact_type string | 
**contact_id** | **int** | contact_id integer | 
**label_id** | **int** | Custom label of the contact | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


