# GetOpportunitiesGroupsGroupIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**group_id** | **int** | group_id integer | 
**name** | **string** | name string | 
**description** | **string** | description string | 
**notification** | **string** | notification string | 
**required_tasks** | **int[]** | Tasks need to complete for this group | 
**connected_groups** | **int[]** | The groups that are connected to this group on the opportunities map | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


