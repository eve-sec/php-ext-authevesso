# GetCharactersCharacterIdStatsMining

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**drone_mine** | **int** | drone_mine integer | [optional] 
**ore_arkonor** | **int** | ore_arkonor integer | [optional] 
**ore_bistot** | **int** | ore_bistot integer | [optional] 
**ore_crokite** | **int** | ore_crokite integer | [optional] 
**ore_dark_ochre** | **int** | ore_dark_ochre integer | [optional] 
**ore_gneiss** | **int** | ore_gneiss integer | [optional] 
**ore_harvestable_cloud** | **int** | ore_harvestable_cloud integer | [optional] 
**ore_hedbergite** | **int** | ore_hedbergite integer | [optional] 
**ore_hemorphite** | **int** | ore_hemorphite integer | [optional] 
**ore_ice** | **int** | ore_ice integer | [optional] 
**ore_jaspet** | **int** | ore_jaspet integer | [optional] 
**ore_kernite** | **int** | ore_kernite integer | [optional] 
**ore_mercoxit** | **int** | ore_mercoxit integer | [optional] 
**ore_omber** | **int** | ore_omber integer | [optional] 
**ore_plagioclase** | **int** | ore_plagioclase integer | [optional] 
**ore_pyroxeres** | **int** | ore_pyroxeres integer | [optional] 
**ore_scordite** | **int** | ore_scordite integer | [optional] 
**ore_spodumain** | **int** | ore_spodumain integer | [optional] 
**ore_veldspar** | **int** | ore_veldspar integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


