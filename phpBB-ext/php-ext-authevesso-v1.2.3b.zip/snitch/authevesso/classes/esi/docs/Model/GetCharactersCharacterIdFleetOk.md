# GetCharactersCharacterIdFleetOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fleet_id** | **int** | The character&#39;s current fleet ID | 
**wing_id** | **int** | ID of the wing the member is in. If not applicable, will be set to -1 | 
**squad_id** | **int** | ID of the squad the member is in. If not applicable, will be set to -1 | 
**role** | **string** | Member’s role in fleet | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


