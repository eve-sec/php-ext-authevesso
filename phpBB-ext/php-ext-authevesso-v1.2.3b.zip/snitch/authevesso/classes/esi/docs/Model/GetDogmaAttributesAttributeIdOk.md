# GetDogmaAttributesAttributeIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attribute_id** | **int** | attribute_id integer | 
**name** | **string** | name string | [optional] 
**description** | **string** | description string | [optional] 
**icon_id** | **int** | icon_id integer | [optional] 
**default_value** | **float** | default_value number | [optional] 
**published** | **bool** | published boolean | [optional] 
**display_name** | **string** | display_name string | [optional] 
**unit_id** | **int** | unit_id integer | [optional] 
**stackable** | **bool** | stackable boolean | [optional] 
**high_is_good** | **bool** | high_is_good boolean | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


