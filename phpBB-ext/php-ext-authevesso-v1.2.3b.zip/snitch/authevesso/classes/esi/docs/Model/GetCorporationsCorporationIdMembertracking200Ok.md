# GetCorporationsCorporationIdMembertracking200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**character_id** | **int** | character_id integer | 
**start_date** | [**\DateTime**](\DateTime.md) | start_date string | [optional] 
**base_id** | **int** | base_id integer | [optional] 
**logon_date** | [**\DateTime**](\DateTime.md) | logon_date string | [optional] 
**logoff_date** | [**\DateTime**](\DateTime.md) | logoff_date string | [optional] 
**location_id** | **int** | location_id integer | [optional] 
**ship_type_id** | **int** | ship_type_id integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


