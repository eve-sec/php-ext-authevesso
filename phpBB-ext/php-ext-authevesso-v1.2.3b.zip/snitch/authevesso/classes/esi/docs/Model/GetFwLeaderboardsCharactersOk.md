# GetFwLeaderboardsCharactersOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kills** | [**\Swagger\Client\Model\GetFwLeaderboardsCharactersKills**](GetFwLeaderboardsCharactersKills.md) |  | [optional] 
**victory_points** | [**\Swagger\Client\Model\GetFwLeaderboardsCharactersVictoryPoints**](GetFwLeaderboardsCharactersVictoryPoints.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


