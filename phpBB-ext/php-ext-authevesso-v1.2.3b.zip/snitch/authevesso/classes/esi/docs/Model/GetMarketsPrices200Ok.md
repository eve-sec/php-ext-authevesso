# GetMarketsPrices200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type_id** | **int** | type_id integer | 
**average_price** | **double** | average_price number | [optional] 
**adjusted_price** | **double** | adjusted_price number | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


