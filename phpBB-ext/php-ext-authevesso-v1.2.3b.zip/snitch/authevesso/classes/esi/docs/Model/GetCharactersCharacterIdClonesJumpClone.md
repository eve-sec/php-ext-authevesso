# GetCharactersCharacterIdClonesJumpClone

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jump_clone_id** | **int** | jump_clone_id integer | 
**name** | **string** | name string | [optional] 
**location_id** | **int** | location_id integer | 
**location_type** | **string** | location_type string | 
**implants** | **int[]** | implants array | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


