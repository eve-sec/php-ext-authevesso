# GetKillmailsKillmailIdKillmailHashOkVictimItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flag** | **int** | flag integer | 
**item_type_id** | **int** | item_type_id integer | 
**quantity_destroyed** | **int** | quantity_destroyed integer | [optional] 
**quantity_dropped** | **int** | quantity_dropped integer | [optional] 
**singleton** | **int** | singleton integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


