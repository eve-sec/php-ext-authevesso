# GetCharactersCharacterIdBookmarks200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bookmark_id** | **int** | bookmark_id integer | 
**folder_id** | **int** | folder_id integer | [optional] 
**created** | [**\DateTime**](\DateTime.md) | created string | 
**label** | **string** | label string | 
**notes** | **string** | notes string | 
**location_id** | **int** | location_id integer | 
**creator_id** | **int** | creator_id integer | 
**item** | [**\Swagger\Client\Model\GetCharactersCharacterIdBookmarksItem**](GetCharactersCharacterIdBookmarksItem.md) |  | [optional] 
**coordinates** | [**\Swagger\Client\Model\GetCharactersCharacterIdBookmarksCoordinates**](GetCharactersCharacterIdBookmarksCoordinates.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


