# GetKillmailsKillmailIdKillmailHashVictim

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**character_id** | **int** | character_id integer | [optional] 
**corporation_id** | **int** | corporation_id integer | [optional] 
**alliance_id** | **int** | alliance_id integer | [optional] 
**faction_id** | **int** | faction_id integer | [optional] 
**damage_taken** | **int** | How much total damage was taken by the victim | 
**ship_type_id** | **int** | The ship that the victim was piloting and was destroyed | 
**items** | [**\Swagger\Client\Model\GetKillmailsKillmailIdKillmailHashItem1[]**](GetKillmailsKillmailIdKillmailHashItem1.md) | items array | [optional] 
**position** | [**\Swagger\Client\Model\GetKillmailsKillmailIdKillmailHashPosition**](GetKillmailsKillmailIdKillmailHashPosition.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


