# GetCharactersCharacterIdMedals200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**medal_id** | **int** | medal_id integer | 
**title** | **string** | title string | 
**description** | **string** | description string | 
**corporation_id** | **int** | corporation_id integer | 
**issuer_id** | **int** | issuer_id integer | 
**date** | [**\DateTime**](\DateTime.md) | date string | 
**reason** | **string** | reason string | 
**status** | **string** | status string | 
**graphics** | [**\Swagger\Client\Model\GetCharactersCharacterIdMedalsGraphic[]**](GetCharactersCharacterIdMedalsGraphic.md) | graphics array | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


