# GetCharactersCharacterIdMedalsGraphic

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**part** | **int** | part integer | 
**layer** | **int** | layer integer | 
**graphic** | **string** | graphic string | 
**color** | **int** | color integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


