# GetCharactersCharacterIdPlanetsPlanetIdOkExtractorDetailsHeads

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**head_id** | **int** | head_id integer | 
**latitude** | **float** | latitude number | 
**longitude** | **float** | longitude number | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


