# GetCharactersCharacterIdChatChannelsAllowed

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accessor_id** | **int** | ID of an allowed channel member | 
**accessor_type** | **string** | accessor_type string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


