# GetCharactersCharacterIdNotifications200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**notification_id** | **int** | notification_id integer | 
**type** | **string** | type string | 
**sender_id** | **int** | sender_id integer | 
**sender_type** | **string** | sender_type string | 
**timestamp** | [**\DateTime**](\DateTime.md) | timestamp string | 
**is_read** | **bool** | is_read boolean | [optional] 
**text** | **string** | text string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


