# GetInsurancePrices200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type_id** | **int** | type_id integer | 
**levels** | [**\Swagger\Client\Model\GetInsurancePricesLevel[]**](GetInsurancePricesLevel.md) | A list of a available insurance levels for this ship type | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


