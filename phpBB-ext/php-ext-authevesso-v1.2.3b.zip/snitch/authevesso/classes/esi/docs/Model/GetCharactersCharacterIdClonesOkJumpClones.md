# GetCharactersCharacterIdClonesOkJumpClones

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**implants** | **int[]** | implants array | [optional] 
**location_id** | **int** | location_id integer | [optional] 
**location_type** | **string** | location_type string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


