# GetCharactersCharacterIdContactsLabels200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label_id** | **int** | label_id integer | 
**label_name** | **string** | label_name string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


