# GetUniverseGraphicsGraphicIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**graphic_id** | **int** | graphic_id integer | 
**graphic_file** | **string** | graphic_file string | [optional] 
**sof_race_name** | **string** | sof_race_name string | [optional] 
**sof_fation_name** | **string** | sof_fation_name string | [optional] 
**sof_dna** | **string** | sof_dna string | [optional] 
**sof_hull_name** | **string** | sof_hull_name string | [optional] 
**collision_file** | **string** | collision_file string | [optional] 
**icon_folder** | **string** | icon_folder string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


