# GetIndustrySystemsCostIndice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**activity** | **string** | activity string | 
**cost_index** | **float** | cost_index number | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


