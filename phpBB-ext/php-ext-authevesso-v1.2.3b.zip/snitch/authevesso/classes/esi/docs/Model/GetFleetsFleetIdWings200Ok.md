# GetFleetsFleetIdWings200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | name string | 
**id** | **int** | id integer | 
**squads** | [**\Swagger\Client\Model\GetFleetsFleetIdWingsSquad[]**](GetFleetsFleetIdWingsSquad.md) | squads array | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


