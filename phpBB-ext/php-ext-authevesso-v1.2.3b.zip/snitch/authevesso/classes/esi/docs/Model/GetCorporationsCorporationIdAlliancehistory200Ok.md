# GetCorporationsCorporationIdAlliancehistory200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_date** | [**\DateTime**](\DateTime.md) | start_date string | 
**alliance_id** | **int** | alliance_id integer | [optional] 
**is_deleted** | **bool** | True if the alliance has been closed | [optional] 
**record_id** | **int** | An incrementing ID that can be used to canonically establish order of records in cases where dates may be ambiguous | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


