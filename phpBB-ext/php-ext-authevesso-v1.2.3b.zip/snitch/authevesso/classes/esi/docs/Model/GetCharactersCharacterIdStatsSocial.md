# GetCharactersCharacterIdStatsSocial

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**add_contact_bad** | **int** | add_contact_bad integer | [optional] 
**add_contact_good** | **int** | add_contact_good integer | [optional] 
**add_contact_high** | **int** | add_contact_high integer | [optional] 
**add_contact_horrible** | **int** | add_contact_horrible integer | [optional] 
**add_contact_neutral** | **int** | add_contact_neutral integer | [optional] 
**add_note** | **int** | add_note integer | [optional] 
**added_as_contact_bad** | **int** | added_as_contact_bad integer | [optional] 
**added_as_contact_good** | **int** | added_as_contact_good integer | [optional] 
**added_as_contact_high** | **int** | added_as_contact_high integer | [optional] 
**added_as_contact_horrible** | **int** | added_as_contact_horrible integer | [optional] 
**added_as_contact_neutral** | **int** | added_as_contact_neutral integer | [optional] 
**calendar_event_created** | **int** | calendar_event_created integer | [optional] 
**chat_messages_alliance** | **int** | chat_messages_alliance integer | [optional] 
**chat_messages_constellation** | **int** | chat_messages_constellation integer | [optional] 
**chat_messages_corporation** | **int** | chat_messages_corporation integer | [optional] 
**chat_messages_fleet** | **int** | chat_messages_fleet integer | [optional] 
**chat_messages_region** | **int** | chat_messages_region integer | [optional] 
**chat_messages_solarsystem** | **int** | chat_messages_solarsystem integer | [optional] 
**chat_messages_warfaction** | **int** | chat_messages_warfaction integer | [optional] 
**chat_total_message_length** | **int** | chat_total_message_length integer | [optional] 
**direct_trades** | **int** | direct_trades integer | [optional] 
**fleet_broadcasts** | **int** | fleet_broadcasts integer | [optional] 
**fleet_joins** | **int** | fleet_joins integer | [optional] 
**mails_received** | **int** | mails_received integer | [optional] 
**mails_sent** | **int** | mails_sent integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


