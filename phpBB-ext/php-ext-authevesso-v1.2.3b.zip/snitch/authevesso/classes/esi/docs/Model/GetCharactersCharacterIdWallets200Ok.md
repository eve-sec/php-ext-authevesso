# GetCharactersCharacterIdWallets200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**balance** | **int** | Wallet&#39;s balance in ISK hundredths. | [optional] 
**wallet_id** | **int** | wallet_id integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


