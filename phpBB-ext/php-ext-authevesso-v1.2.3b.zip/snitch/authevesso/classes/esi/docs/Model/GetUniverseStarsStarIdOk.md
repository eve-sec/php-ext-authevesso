# GetUniverseStarsStarIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | name string | 
**solar_system_id** | **int** | solar_system_id integer | 
**type_id** | **int** | type_id integer | 
**age** | **int** | Age of star in years | 
**luminosity** | **float** | luminosity number | 
**radius** | **int** | radius integer | 
**spectral_class** | **string** | spectral_class string | 
**temperature** | **int** | temperature integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


