# GetCharactersCharacterIdPlanetsPlanetIdPin

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**latitude** | **float** | latitude number | 
**longitude** | **float** | longitude number | 
**pin_id** | **int** | pin_id integer | 
**type_id** | **int** | type_id integer | 
**schematic_id** | **int** | schematic_id integer | [optional] 
**extractor_details** | [**\Swagger\Client\Model\GetCharactersCharacterIdPlanetsPlanetIdExtractorDetails**](GetCharactersCharacterIdPlanetsPlanetIdExtractorDetails.md) |  | [optional] 
**factory_details** | [**\Swagger\Client\Model\GetCharactersCharacterIdPlanetsPlanetIdFactoryDetails**](GetCharactersCharacterIdPlanetsPlanetIdFactoryDetails.md) |  | [optional] 
**contents** | [**\Swagger\Client\Model\GetCharactersCharacterIdPlanetsPlanetIdContent[]**](GetCharactersCharacterIdPlanetsPlanetIdContent.md) | contents array | [optional] 
**install_time** | [**\DateTime**](\DateTime.md) | install_time string | [optional] 
**expiry_time** | [**\DateTime**](\DateTime.md) | expiry_time string | [optional] 
**last_cycle_start** | [**\DateTime**](\DateTime.md) | last_cycle_start string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


