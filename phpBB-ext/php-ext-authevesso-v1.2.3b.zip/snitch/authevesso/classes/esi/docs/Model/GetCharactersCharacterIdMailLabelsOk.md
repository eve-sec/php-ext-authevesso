# GetCharactersCharacterIdMailLabelsOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_unread_count** | **int** | total_unread_count integer | [optional] 
**labels** | [**\Swagger\Client\Model\GetCharactersCharacterIdMailLabelsLabel[]**](GetCharactersCharacterIdMailLabelsLabel.md) | labels array | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


