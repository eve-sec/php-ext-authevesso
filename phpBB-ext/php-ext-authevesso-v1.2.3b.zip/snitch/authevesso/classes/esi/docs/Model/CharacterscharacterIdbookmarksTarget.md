# CharacterscharacterIdbookmarksTarget

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**coordinates** | [**\Swagger\Client\Model\CharacterscharacterIdbookmarksTargetCoordinates**](CharacterscharacterIdbookmarksTargetCoordinates.md) |  | [optional] 
**item** | [**\Swagger\Client\Model\CharacterscharacterIdbookmarksTargetItem**](CharacterscharacterIdbookmarksTargetItem.md) |  | [optional] 
**location_id** | **int** | location_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


