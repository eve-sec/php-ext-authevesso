# GetCharactersCharacterIdMailLabelsLabel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unread_count** | **int** | unread_count integer | [optional] 
**label_id** | **int** | label_id integer | [optional] 
**name** | **string** | name string | [optional] 
**color** | **string** | color string | [optional] [default to '#ffffff']

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


