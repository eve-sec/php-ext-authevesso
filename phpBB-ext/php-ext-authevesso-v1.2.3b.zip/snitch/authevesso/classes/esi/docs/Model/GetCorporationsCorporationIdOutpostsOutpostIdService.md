# GetCorporationsCorporationIdOutpostsOutpostIdService

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**service_name** | **string** | service_name string | 
**minimum_standing** | **double** | minimum_standing number | 
**surcharge_per_bad_standing** | **double** | surcharge_per_bad_standing number | 
**discount_per_good_standing** | **double** | discount_per_good_standing number | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


