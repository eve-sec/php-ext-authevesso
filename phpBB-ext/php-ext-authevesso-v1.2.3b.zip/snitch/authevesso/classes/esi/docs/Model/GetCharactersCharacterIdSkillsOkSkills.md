# GetCharactersCharacterIdSkillsOkSkills

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**current_skill_level** | **int** | current_skill_level integer | [optional] 
**skill_id** | **int** | skill_id integer | [optional] 
**skillpoints_in_skill** | **int** | skillpoints_in_skill integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


