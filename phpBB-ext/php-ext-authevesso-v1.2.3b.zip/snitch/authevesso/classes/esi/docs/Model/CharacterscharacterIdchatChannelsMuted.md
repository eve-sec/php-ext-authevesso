# CharacterscharacterIdchatChannelsMuted

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accessor_id** | **int** | ID of a muted channel member | 
**accessor_type** | **string** | accessor_type string | 
**end_at** | [**\DateTime**](\DateTime.md) | Time at which this accessor will no longer be muted | [optional] 
**reason** | **string** | Reason this accessor is muted | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


