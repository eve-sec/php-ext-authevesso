# GetUniverseCategoriesCategoryIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**category_id** | **int** | category_id integer | 
**name** | **string** | name string | 
**published** | **bool** | published boolean | 
**groups** | **int[]** | groups array | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


