# GetCharactersCharacterIdRolesOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**roles** | **string[]** | roles array | [optional] 
**roles_at_hq** | **string[]** | roles_at_hq array | [optional] 
**roles_at_base** | **string[]** | roles_at_base array | [optional] 
**roles_at_other** | **string[]** | roles_at_other array | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


