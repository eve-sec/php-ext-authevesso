# GetCharactersCharacterIdOpportunities200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**task_id** | **int** | task_id integer | 
**completed_at** | [**\DateTime**](\DateTime.md) | completed_at string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


