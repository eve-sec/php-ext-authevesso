# GetUniverseSchematicsSchematicIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**schematic_name** | **string** | schematic_name string | 
**cycle_time** | **int** | Time in seconds to process a run | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


