# GetCharactersCharacterIdStatsIsk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**in** | **int** | in integer | [optional] 
**out** | **int** | out integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


