# GetUniverseStargatesStargateIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stargate_id** | **int** | stargate_id integer | 
**name** | **string** | name string | 
**type_id** | **int** | type_id integer | 
**position** | [**\Swagger\Client\Model\GetUniverseStargatesStargateIdPosition**](GetUniverseStargatesStargateIdPosition.md) |  | [optional] 
**system_id** | **int** | The solar system this stargate is in | 
**destination** | [**\Swagger\Client\Model\GetUniverseStargatesStargateIdDestination**](GetUniverseStargatesStargateIdDestination.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


