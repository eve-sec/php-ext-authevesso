# GetUniverseRegionsRegionIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**region_id** | **int** | region_id integer | 
**name** | **string** | name string | 
**description** | **string** | description string | [optional] 
**constellations** | **int[]** | constellations array | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


