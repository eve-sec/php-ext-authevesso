# GetMarketsGroupsMarketGroupIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**market_group_id** | **int** | market_group_id integer | 
**name** | **string** | name string | 
**description** | **string** | description string | 
**types** | **int[]** | types array | 
**parent_group_id** | **int** | parent_group_id integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


