# GetCharactersCharacterIdPlanetsPlanetIdExtractorDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**heads** | [**\Swagger\Client\Model\GetCharactersCharacterIdPlanetsPlanetIdHead[]**](GetCharactersCharacterIdPlanetsPlanetIdHead.md) | heads array | 
**product_type_id** | **int** | product_type_id integer | [optional] 
**cycle_time** | **int** | in seconds | [optional] 
**head_radius** | **float** | head_radius number | [optional] 
**qty_per_cycle** | **int** | qty_per_cycle integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


