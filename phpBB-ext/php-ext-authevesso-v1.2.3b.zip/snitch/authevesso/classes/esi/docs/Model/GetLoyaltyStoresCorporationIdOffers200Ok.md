# GetLoyaltyStoresCorporationIdOffers200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offer_id** | **int** | offer_id integer | 
**type_id** | **int** | type_id integer | 
**quantity** | **int** | quantity integer | 
**lp_cost** | **int** | lp_cost integer | 
**isk_cost** | **float** | isk_cost number | 
**required_items** | [**\Swagger\Client\Model\GetLoyaltyStoresCorporationIdOffersRequiredItem[]**](GetLoyaltyStoresCorporationIdOffersRequiredItem.md) | required_items array | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


