# GetKillmailsKillmailIdKillmailHashItem1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**item_type_id** | **int** | item_type_id integer | 
**quantity_destroyed** | **int** | How many of the item were destroyed if any | [optional] 
**quantity_dropped** | **int** | How many of the item were dropped if any | [optional] 
**singleton** | **int** | singleton integer | 
**flag** | **int** | Flag for the location of the item | 
**items** | [**\Swagger\Client\Model\GetKillmailsKillmailIdKillmailHashItem[]**](GetKillmailsKillmailIdKillmailHashItem.md) | items array | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


