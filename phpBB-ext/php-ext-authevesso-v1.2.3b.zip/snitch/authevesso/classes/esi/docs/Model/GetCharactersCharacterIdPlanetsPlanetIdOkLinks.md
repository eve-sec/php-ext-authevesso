# GetCharactersCharacterIdPlanetsPlanetIdOkLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**destination_pin_id** | **int** | destination_pin_id integer | 
**link_level** | **int** | link_level integer | 
**source_pin_id** | **int** | source_pin_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


