# GetCorporationCorporationIdMiningObservers200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**last_updated** | [**\DateTime**](Date.md) | last_updated string | 
**observer_id** | **int** | The entity that was observing the asteroid field when it was mined. | 
**observer_type** | **string** | The category of the observing entity | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


