# GetCorporationsCorporationIdBookmarksFolders200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**folder_id** | **int** | folder_id integer | 
**name** | **string** | name string | 
**creator_id** | **int** | creator_id integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


