# GetCharactersCharacterIdStatsCharacter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**days_of_activity** | **int** | days_of_activity integer | [optional] 
**minutes** | **int** | minutes integer | [optional] 
**sessions_started** | **int** | sessions_started integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


