# GetCharactersCharacterIdStats200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**year** | **int** | Gregorian year for this set of aggregates | 
**character** | [**\Swagger\Client\Model\GetCharactersCharacterIdStatsCharacter**](GetCharactersCharacterIdStatsCharacter.md) |  | [optional] 
**combat** | [**\Swagger\Client\Model\GetCharactersCharacterIdStatsCombat**](GetCharactersCharacterIdStatsCombat.md) |  | [optional] 
**industry** | [**\Swagger\Client\Model\GetCharactersCharacterIdStatsIndustry**](GetCharactersCharacterIdStatsIndustry.md) |  | [optional] 
**inventory** | [**\Swagger\Client\Model\GetCharactersCharacterIdStatsInventory**](GetCharactersCharacterIdStatsInventory.md) |  | [optional] 
**isk** | [**\Swagger\Client\Model\GetCharactersCharacterIdStatsIsk**](GetCharactersCharacterIdStatsIsk.md) |  | [optional] 
**market** | [**\Swagger\Client\Model\GetCharactersCharacterIdStatsMarket**](GetCharactersCharacterIdStatsMarket.md) |  | [optional] 
**mining** | [**\Swagger\Client\Model\GetCharactersCharacterIdStatsMining**](GetCharactersCharacterIdStatsMining.md) |  | [optional] 
**module** | [**\Swagger\Client\Model\GetCharactersCharacterIdStatsModule**](GetCharactersCharacterIdStatsModule.md) |  | [optional] 
**orbital** | [**\Swagger\Client\Model\GetCharactersCharacterIdStatsOrbital**](GetCharactersCharacterIdStatsOrbital.md) |  | [optional] 
**pve** | [**\Swagger\Client\Model\GetCharactersCharacterIdStatsPve**](GetCharactersCharacterIdStatsPve.md) |  | [optional] 
**social** | [**\Swagger\Client\Model\GetCharactersCharacterIdStatsSocial**](GetCharactersCharacterIdStatsSocial.md) |  | [optional] 
**travel** | [**\Swagger\Client\Model\GetCharactersCharacterIdStatsTravel**](GetCharactersCharacterIdStatsTravel.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


