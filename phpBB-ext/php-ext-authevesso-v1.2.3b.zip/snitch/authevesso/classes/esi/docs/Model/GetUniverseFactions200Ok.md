# GetUniverseFactions200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**faction_id** | **int** | faction_id integer | 
**name** | **string** | name string | 
**description** | **string** | description string | 
**solar_system_id** | **int** | solar_system_id integer | [optional] 
**corporation_id** | **int** | corporation_id integer | [optional] 
**militia_corporation_id** | **int** | militia_corporation_id integer | [optional] 
**size_factor** | **float** | size_factor number | 
**station_count** | **int** | station_count integer | 
**station_system_count** | **int** | station_system_count integer | 
**is_unique** | **bool** | is_unique boolean | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


